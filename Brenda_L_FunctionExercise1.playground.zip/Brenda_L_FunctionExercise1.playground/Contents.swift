func multiTwoNumbers(num1: Int, num2: Int) -> Int {
        return num1 * num2
}
multiTwoNumbers(num1: 3, num2: 2)

var multiTwoNumbers2 = { (num1: Int, num2: Int) -> Int in
    return num1 * num2
}

//using the closure
print(multiTwoNumbers2(3,9))
multiTwoNumbers2(2,3)
